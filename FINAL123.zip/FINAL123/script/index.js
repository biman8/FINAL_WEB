
// Example code for handling button clicks
const button = document.querySelector('.apply-button');

button.addEventListener('click', () => {
  alert('Button clicked!');
});